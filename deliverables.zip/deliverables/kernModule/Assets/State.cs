﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class State : MonoBehaviour {

	public delegate void StateEvent onState();




	public abstract void Start ();

	public abstract void Run();

	public abstract void completed();


}

public class AliveState: State{

	public override void run
}

public class Deadstate : State {

	public override void Start(){
		
	}

	public override void Run(){
		
	}

	public override void completed(){
	}
} 

public class FiniteStateMachine{
	private State currentState;

	public void SetState(State newstate){
		if (currentState != null) {
			currentState.completed ();
			currentState.Onstate -= SetState;
		}

		newstate.Start ();
		newstate.Onstate ();
		currentState.newState ();

}